// XTC format reader/parser for XTEink X4 e-reader

import { TARGET_WIDTH, TARGET_HEIGHT } from './processing/canvas'
import type { BookMetadata, TocEntry } from './metadata/types'
import { decompressXtczLz4 } from './processing/lz4-compress'

export interface XtcHeader {
  magic: string
  is2bit: boolean
  version: number
  pageCount: number
  hasMetadata: boolean
  metadataOffset: bigint
  indexOffset: bigint
  dataOffset: bigint
  tocOffset: bigint
  isXtcz?: boolean
}

export interface XtcIndexEntry {
  offset: bigint
  size: number
  width: number
  height: number
}

export interface ParsedXtc {
  header: XtcHeader
  metadata?: BookMetadata
  entries: XtcIndexEntry[]
  pageData: ArrayBuffer[]
  rawBuffer: ArrayBuffer
}

/**
 * Helper to check if a buffer is XTCZ and decompress if necessary
 */
function getDecompressedBuffer(buffer: ArrayBuffer): { buffer: ArrayBuffer, isXtcz: boolean } {
  if (buffer.byteLength >= 4) {
    const uint8 = new Uint8Array(buffer, 0, 4);
    if (uint8[0] === 88 && uint8[1] === 84 && uint8[2] === 90 && uint8[3] === 52) { // XTZ4
      return { buffer: decompressXtczLz4(buffer), isXtcz: true };
    }
  }
  return { buffer, isXtcz: false };
}

/**
 * Parse XTC file header (48-56 bytes)
 */
function parseXtcHeader(view: DataView): XtcHeader {
  const uint8 = new Uint8Array(view.buffer, view.byteOffset, 4)
  const magic = String.fromCharCode(uint8[0], uint8[1], uint8[2])
  const is2bit = uint8[3] === 0x48 || uint8[3] === 0x68 // 'H' or 'h'

  if (magic !== 'XTC') {
    throw new Error('Invalid XTC file: bad magic number')
  }

  const flagsLow = view.getUint32(8, true)
  const hasMetadata = flagsLow !== 0

  return {
    magic,
    is2bit,
    version: view.getUint16(4, true),
    pageCount: view.getUint16(6, true),
    hasMetadata,
    metadataOffset: getBigUint64(view, 16),
    indexOffset: getBigUint64(view, 24),
    dataOffset: getBigUint64(view, 32),
    tocOffset: hasMetadata && view.byteLength >= 56 ? getBigUint64(view, 48) : 0n,
  }
}

/**
 * Parse null-terminated string from ArrayBuffer
 */
function readNullTerminatedString(view: DataView, offset: number, maxLength: number): string {
  const bytes = new Uint8Array(view.buffer, view.byteOffset + offset, maxLength)
  let len = 0
  while (len < maxLength && bytes[len] !== 0) {
    len++
  }
  return new TextDecoder('utf-8').decode(bytes.subarray(0, len))
}

/**
 * Parse XTC metadata
 */
function parseMetadata(view: DataView, header: XtcHeader): BookMetadata {
  const metadata: BookMetadata = { toc: [] }
  if (!header.hasMetadata || header.metadataOffset === 0n) return metadata

  const metaOffset = Number(header.metadataOffset)
  metadata.title = readNullTerminatedString(view, metaOffset, 128)
  metadata.author = readNullTerminatedString(view, metaOffset + 128, 64)
  metadata.publisher = readNullTerminatedString(view, metaOffset + 192, 32)
  metadata.language = readNullTerminatedString(view, metaOffset + 224, 16)

  const tocHeaderOffset = metaOffset + 240
  metadata.createTime = view.getUint32(tocHeaderOffset, true)
  metadata.coverPage = view.getUint16(tocHeaderOffset + 4, true)
  const chapterCount = view.getUint16(tocHeaderOffset + 6, true)

  const tocOffset = header.tocOffset !== 0n ? Number(header.tocOffset) : tocHeaderOffset + 16

  for (let i = 0; i < chapterCount; i++) {
    const entryOffset = tocOffset + i * 96
    const title = readNullTerminatedString(view, entryOffset, 80)
    const startPage = view.getUint16(entryOffset + 80, true)
    const endPage = view.getUint16(entryOffset + 82, true)
    metadata.toc.push({ title, startPage, endPage })
  }

  return metadata
}

/**
 * Parse XTC index entry (16 bytes each)
 */
function parseIndexEntry(view: DataView, offset: number): XtcIndexEntry {
  return {
    offset: getBigUint64(view, offset),
    size: view.getUint32(offset + 8, true),
    width: view.getUint16(offset + 12, true),
    height: view.getUint16(offset + 14, true),
  }
}

/**
 * Parse an XTC file and extract all page data
 */
export async function parseXtcFile(inputBuffer: ArrayBuffer): Promise<ParsedXtc> {
  const { buffer, isXtcz } = getDecompressedBuffer(inputBuffer);
  const view = new DataView(buffer)
  const header = parseXtcHeader(view)
  header.isXtcz = isXtcz;
  const metadata = parseMetadata(view, header)

  const entries: XtcIndexEntry[] = []
  const indexOffset = Number(header.indexOffset)

  for (let i = 0; i < header.pageCount; i++) {
    const entryOffset = indexOffset + i * 16
    entries.push(parseIndexEntry(view, entryOffset))
  }

  const pageData: ArrayBuffer[] = []
  for (const entry of entries) {
    const offset = Number(entry.offset)
    const data = buffer.slice(offset, offset + entry.size)
    pageData.push(data)
  }

  return { header, metadata, entries, pageData, rawBuffer: buffer }
}

/**
 * Get page count from XTC file without parsing all data
 */
export async function getXtcPageCount(inputBuffer: ArrayBuffer): Promise<number> {
  const { buffer } = getDecompressedBuffer(inputBuffer);
  const view = new DataView(buffer)
  const header = parseXtcHeader(view)
  return header.pageCount
}

/**
 * Decode XTG or XTH page data to canvas
 */
export function decodeXtcPageToCanvas(pageBuffer: ArrayBuffer): HTMLCanvasElement {
  const view = new DataView(pageBuffer)
  const uint8 = new Uint8Array(pageBuffer)

  // Verify magic
  const magic = String.fromCharCode(uint8[0], uint8[1], uint8[2])
  const is2bit = magic === 'XTH'

  if (magic !== 'XTG' && magic !== 'XTH') {
    throw new Error('Invalid page data: bad magic number ' + magic)
  }

  const width = view.getUint16(4, true)
  const height = view.getUint16(6, true)
  const headerSize = 22

  const canvas = document.createElement('canvas')
  canvas.width = width
  canvas.height = height
  const ctx = canvas.getContext('2d')!

  const imageData = ctx.createImageData(width, height)
  const data = imageData.data

  if (is2bit) {
    const colBytes = Math.ceil(height / 8)
    const planeSize = colBytes * width
    const p0 = new Uint8Array(pageBuffer, headerSize, planeSize)
    const p1 = new Uint8Array(pageBuffer, headerSize + planeSize, planeSize)

    for (let x = 0; x < width; x++) {
      const targetCol = width - 1 - x
      const colOffset = targetCol * colBytes
      for (let y = 0; y < height; y++) {
        const byteIdx = colOffset + (y >> 3)
        const bitIdx = 7 - (y % 8)
        
        const bit0 = (p0[byteIdx] >> bitIdx) & 1
        const bit1 = (p1[byteIdx] >> bitIdx) & 1
        const val = bit0 | (bit1 << 1)

        let color = 255
        if (val === 0) color = 255
        else if (val === 1) color = 170
        else if (val === 2) color = 85
        else color = 0

        const idx = (y * width + x) * 4
        data[idx] = color
        data[idx + 1] = color
        data[idx + 2] = color
        data[idx + 3] = 255
      }
    }
  } else {
    const pixelDataSize = view.getUint32(10, true)
    const pixelData = new Uint8Array(pageBuffer, headerSize, pixelDataSize)
    const rowBytes = Math.ceil(width / 8)

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const byteIndex = y * rowBytes + Math.floor(x / 8)
        const bitIndex = 7 - (x % 8)
        const bit = (pixelData[byteIndex] >> bitIndex) & 1

        const idx = (y * width + x) * 4
        const color = bit ? 255 : 0
        data[idx] = color
        data[idx + 1] = color
        data[idx + 2] = color
        data[idx + 3] = 255
      }
    }
  }

  ctx.putImageData(imageData, 0, 0)
  return canvas
}

/**
 * Extract all pages from XTC as canvases
 */
export async function extractXtcPages(buffer: ArrayBuffer): Promise<HTMLCanvasElement[]> {
  const parsed = await parseXtcFile(buffer)
  return parsed.pageData.map(data => decodeXtcPageToCanvas(data))
}

/**
 * Extract raw XTG page data from XTC (for direct copy during merge)
 */
export async function extractXtcRawPages(buffer: ArrayBuffer): Promise<ArrayBuffer[]> {
  const parsed = await parseXtcFile(buffer)
  return parsed.pageData
}

/**
 * Helper to read 64-bit unsigned integer (little-endian)
 */
function getBigUint64(view: DataView, offset: number): bigint {
  const low = view.getUint32(offset, true)
  const high = view.getUint32(offset + 4, true)
  return BigInt(low) + (BigInt(high) << 32n)
}
