// Dithering algorithms optimized for manga on e-ink displays
// Each algorithm has different characteristics for handling manga art

import { runWasmDither, isWasmLoaded } from './wasm'

/**
 * Applies the selected dithering algorithm to canvas
 */
export function applyDithering(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  algorithm: string,
  is2bit: boolean = false,
  useWasm: boolean = false
): void {
  const imageData = ctx.getImageData(0, 0, width, height);
  applyDitheringToData(imageData.data, width, height, algorithm, is2bit, useWasm);
  ctx.putImageData(imageData, 0, 0);
}

/**
 * Applies the selected dithering algorithm to raw pixel data
 */
export function applyDitheringToData(
  data: Uint8ClampedArray,
  width: number,
  height: number,
  algorithm: string,
  is2bit: boolean = false,
  useWasm: boolean = false
): void {
  if (useWasm && isWasmLoaded() && (algorithm === 'stucki' || algorithm === 'atkinson')) {
    try {
      // @ts-ignore - TS strict mode has ArrayBufferLike/ArrayBuffer generic mismatch
      const tempImgData = new ImageData(data, width, height);
      runWasmDither(tempImgData, algorithm, is2bit);
      return;
    } catch (e) {
      console.warn("Wasm dither failed, fallback to CPU", e);
    }
  }

  switch (algorithm) {
    case 'none':
      applyThreshold(data, is2bit);
      break;
    case 'atkinson':
      applyAtkinson(data, width, height, is2bit);
      break;
    case 'floyd':
      applyFloydSteinberg(data, width, height, is2bit);
      break;
    case 'stucki':
      applyStucki(data, width, height, is2bit);
      break;
    case 'ostromoukhov':
      applyOstromoukhov(data, width, height, is2bit);
      break;
    case 'zhoufang':
      applyZhouFang(data, width, height, is2bit);
      break;
    case 'ordered':
      applyOrdered(data, width, height);
      break;
    case 'stochastic':
      applyStochastic(data, width, height, is2bit);
      break;
    case 'matt-parker':
      applyMattParker(data, width, height, is2bit);
      break;
    default:
      applyFloydSteinberg(data, width, height, is2bit);
  }
}

/**
 * Matt Parker Dithering (3x3 Ordered Dither using Parker Square)
 * From: youtube.com/watch?v=kT4p1GXq4HY
 */
function applyMattParker(data: Uint8ClampedArray, width: number, height: number, is2bit: boolean): void {
  const parker = [
    [0.23, 0.41, 0.29],
    [0.41, 0.37, 0.01],
    [0.29, 0.01, 0.47]
  ];

  for (let y = 0; y < height; y++) {
    const rowOffset = y * width * 4;
    const py = y % 3;
    for (let x = 0; x < width; x++) {
      const idx = rowOffset + x * 4;
      const gray = data[idx] / 255;
      const threshold = parker[x % 3][py];
      
      let val;
      if (is2bit) {
        // Map 0.0-1.0 to 4 levels (0, 85, 170, 255)
        const raw = gray * 3;
        const level = Math.floor(raw + threshold);
        val = Math.min(3, level) * 85;
      } else {
        val = gray > threshold ? 255 : 0;
      }
      
      data[idx] = data[idx + 1] = data[idx + 2] = val;
    }
  }
}

/**
 * Space-Filling Curve Dithering (Velho/Hilbert)
 */
function applyStochastic(data: Uint8ClampedArray, width: number, height: number, is2bit: boolean): void {
  const maxDim = Math.max(width, height);
  let n = 1; while (n < maxDim) n *= 2;
  let error = 0;
  const totalPoints = n * n;
  
  for (let i = 0; i < totalPoints; i++) {
    let t = i; let x = 0; let y = 0;
    for (let s = 1; s < n; s *= 2) {
      const rx = 1 & (t / 2);
      const ry = 1 & (t ^ rx);
      if (ry === 0) {
        if (rx === 1) { x = s - 1 - x; y = s - 1 - y; }
        const tmp = x; x = y; y = tmp;
      }
      x += s * rx; y += s * ry; t = Math.floor(t / 4);
    }

    if (x < width && y < height) {
      const idx = (y * width + x) << 2;
      const currentVal = data[idx] + error;
      let newVal;

      if (is2bit) {
        if (currentVal < 42) newVal = 0;
        else if (currentVal < 127) newVal = 85;
        else if (currentVal < 212) newVal = 170;
        else newVal = 255;
      } else {
        newVal = currentVal < 128 ? 0 : 255;
      }

      data[idx] = data[idx + 1] = data[idx + 2] = newVal;
      error = currentVal - newVal;
    }
  }
}

function applyThreshold(data: Uint8ClampedArray, is2bit: boolean): void {
  const pixels32 = new Uint32Array(data.buffer);
  const len = pixels32.length;
  if (is2bit) {
    for (let i = 0; i < len; i++) {
      const val = pixels32[i] & 0xFF; // Extract R (already grayscale)
      let newVal: number;
      if (val < 42) newVal = 0;
      else if (val < 127) newVal = 85;
      else if (val < 212) newVal = 170;
      else newVal = 255;
      pixels32[i] = newVal | (newVal << 8) | (newVal << 16) | 0xFF000000;
    }
  } else {
    for (let i = 0; i < len; i++) {
      const newVal = (pixels32[i] & 0xFF) < 128 ? 0 : 255;
      pixels32[i] = newVal | (newVal << 8) | (newVal << 16) | 0xFF000000;
    }
  }
}

/**
 * Write quantized Float32 data back to RGBA pixels using Uint32Array for 4x faster writeback.
 */
function writebackDithered(pixels: Uint8ClampedArray, floatData: Float32Array): void {
  const pixels32 = new Uint32Array(pixels.buffer);
  for (let i = 0; i < floatData.length; i++) {
    let val = floatData[i];
    if (val < 0) val = 0; else if (val > 255) val = 255;
    const v = val | 0;
    pixels32[i] = v | (v << 8) | (v << 16) | 0xFF000000;
  }
}

/**
 * Extract grayscale values from RGBA pixels using Uint32Array for 4x faster reads.
 */
function extractGrayscale(pixels: Uint8ClampedArray, width: number, height: number): Float32Array {
  const pixels32 = new Uint32Array(pixels.buffer);
  const data = new Float32Array(width * height);
  for (let i = 0; i < data.length; i++) data[i] = pixels32[i] & 0xFF;
  return data;
}

/**
 * Optimized Floyd-Steinberg
 */
function applyFloydSteinberg(pixels: Uint8ClampedArray, width: number, height: number, is2bit: boolean): void {
  const data = extractGrayscale(pixels, width, height);

  const stride = width;
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = y * stride + x;
      const oldVal = data[idx];
      let newVal;

      if (is2bit) {
        if (oldVal < 42) newVal = 0;
        else if (oldVal < 127) newVal = 85;
        else if (oldVal < 212) newVal = 170;
        else newVal = 255;
      } else {
        newVal = oldVal < 128 ? 0 : 255;
      }

      data[idx] = newVal;
      const err = oldVal - newVal;

      if (x + 1 < width) data[idx + 1] += (err * 7) / 16;
      if (y + 1 < height) {
        if (x > 0) data[idx + stride - 1] += (err * 3) / 16;
        data[idx + stride] += (err * 5) / 16;
        if (x + 1 < width) data[idx + stride + 1] += (err * 1) / 16;
      }
    }
  }

  writebackDithered(pixels, data);
}

/**
 * Optimized Atkinson
 */
function applyAtkinson(pixels: Uint8ClampedArray, width: number, height: number, is2bit: boolean): void {
  const data = extractGrayscale(pixels, width, height);
  
  const stride = width;
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = y * stride + x;
      const oldVal = data[idx];
      let newVal;

      if (is2bit) {
        if (oldVal < 42) newVal = 0;
        else if (oldVal < 127) newVal = 85;
        else if (oldVal < 212) newVal = 170;
        else newVal = 255;
      } else {
        newVal = oldVal < 128 ? 0 : 255;
      }

      data[idx] = newVal;
      const err = (oldVal - newVal) / 8;

      if (err !== 0) {
        if (x + 1 < width) data[idx + 1] += err;
        if (x + 2 < width) data[idx + 2] += err;
        if (y + 1 < height) {
          if (x > 0) data[idx + stride - 1] += err;
          data[idx + stride] += err;
          if (x + 1 < width) data[idx + stride + 1] += err;
        }
        if (y + 2 < height) data[idx + stride * 2] += err;
      }
    }
  }

  writebackDithered(pixels, data);
}

function applyStucki(pixels: Uint8ClampedArray, width: number, height: number, is2bit: boolean): void {
  const data = extractGrayscale(pixels, width, height);

  const stride = width;
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = y * stride + x;
      const oldVal = data[idx];
      let newVal;
      if (is2bit) {
        if (oldVal < 42) newVal = 0; else if (oldVal < 127) newVal = 85; else if (oldVal < 212) newVal = 170; else newVal = 255;
      } else {
        newVal = oldVal < 128 ? 0 : 255;
      }
      data[idx] = newVal;
      const err = oldVal - newVal;
      if (err !== 0) {
        const e = err / 42;
        if (x + 1 < width) data[idx + 1] += e * 8;
        if (x + 2 < width) data[idx + 2] += e * 4;
        if (y + 1 < height) {
          if (x - 2 >= 0) data[idx + stride - 2] += e * 2;
          if (x - 1 >= 0) data[idx + stride - 1] += e * 4;
          data[idx + stride] += e * 8;
          if (x + 1 < width) data[idx + stride + 1] += e * 4;
          if (x + 2 < width) data[idx + stride + 2] += e * 2;
        }
        if (y + 2 < height) {
          if (x - 2 >= 0) data[idx + (stride * 2) - 2] += e * 1;
          if (x - 1 >= 0) data[idx + (stride * 2) - 1] += e * 2;
          data[idx + (stride * 2)] += e * 4;
          if (x + 1 < width) data[idx + (stride * 2) + 1] += e * 2;
          if (x + 2 < width) data[idx + (stride * 2) + 2] += e * 1;
        }
      }
    }
  }
  writebackDithered(pixels, data);
}

function applyZhouFang(pixels: Uint8ClampedArray, width: number, height: number, is2bit: boolean): void {
  const data = extractGrayscale(pixels, width, height);
  const stride = width;
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = y * stride + x;
      const oldVal = data[idx];
      let newVal;
      if (is2bit) {
        if (oldVal < 42) newVal = 0; else if (oldVal < 127) newVal = 85; else if (oldVal < 212) newVal = 170; else newVal = 255;
      } else {
        newVal = oldVal < 128 ? 0 : 255;
      }
      data[idx] = newVal;
      const err = oldVal - newVal;
      if (err !== 0) {
        const e = err / 103;
        if (x + 1 < width) data[idx + 1] += e * 16;
        if (x + 2 < width) data[idx + 2] += e * 9;
        if (y + 1 < height) {
          if (x - 2 >= 0) data[idx + stride - 2] += e * 5;
          if (x - 1 >= 0) data[idx + stride - 1] += e * 11;
          data[idx + stride] += e * 16;
          if (x + 1 < width) data[idx + stride + 1] += e * 11;
          if (x + 2 < width) data[idx + stride + 2] += e * 5;
        }
        if (y + 2 < height) {
          if (x - 2 >= 0) data[idx + (stride * 2) - 2] += e * 3;
          if (x - 1 >= 0) data[idx + (stride * 2) - 1] += e * 5;
          data[idx + (stride * 2)] += e * 9;
          if (x + 1 < width) data[idx + (stride * 2) + 1] += e * 5;
          if (x + 2 < width) data[idx + (stride * 2) + 2] += e * 3;
        }
      }
    }
  }
  writebackDithered(pixels, data);
}

function applyOstromoukhov(pixels: Uint8ClampedArray, width: number, height: number, is2bit: boolean): void {
  const data = extractGrayscale(pixels, width, height);
  const stride = width;
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = y * stride + x;
      const oldVal = data[idx];
      let newVal;
      if (is2bit) {
        if (oldVal < 42) newVal = 0; else if (oldVal < 127) newVal = 85; else if (oldVal < 212) newVal = 170; else newVal = 255;
      } else {
        newVal = oldVal < 128 ? 0 : 255;
      }
      data[idx] = newVal;
      const err = oldVal - newVal;
      if (err !== 0) {
        let v = Math.min(255, Math.max(0, oldVal));
        let d1, d2, d3;
        if (v <= 128) {
          const t = v / 128.0;
          d1 = 0.7 * (1 - t) + 0.3 * t; d2 = 0.2 * (1 - t) + 0.4 * t; d3 = 0.1 * (1 - t) + 0.3 * t;
        } else {
          const t = (v - 128) / 127.0;
          d1 = 0.3 * (1 - t) + 0.7 * t; d2 = 0.4 * (1 - t) + 0.2 * t; d3 = 0.3 * (1 - t) + 0.1 * t;
        }
        if (x + 1 < width) data[idx + 1] += err * d1;
        if (y + 1 < height) {
          if (x > 0) data[idx + stride - 1] += err * d2;
          data[idx + stride] += err * d3;
        }
      }
    }
  }
  writebackDithered(pixels, data);
}

function applyOrdered(data: Uint8ClampedArray, width: number, height: number): void {
  const bayer = [[0,8,2,10],[12,4,14,6],[3,11,1,9],[15,7,13,5]];
  const pixels32 = new Uint32Array(data.buffer);
  for (let y = 0; y < height; y++) {
    const rowOffset = y * width;
    const py = y % 4;
    for (let x = 0; x < width; x++) {
      const newVal = (pixels32[rowOffset + x] & 0xFF) > (bayer[py][x % 4] * 16) ? 255 : 0;
      pixels32[rowOffset + x] = newVal | (newVal << 8) | (newVal << 16) | 0xFF000000;
    }
  }
}

