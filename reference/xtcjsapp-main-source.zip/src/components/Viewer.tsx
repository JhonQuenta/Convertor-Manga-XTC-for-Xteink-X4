import { useState, useEffect, useCallback } from 'react'

interface ViewerProps {
  pages: string[]
  onClose: () => void
  totalPages?: number
}

const PAGES_PER_BATCH = 10

export function Viewer({ pages, onClose, totalPages }: ViewerProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isRotated, setIsRotated] = useState(false)
  const [visibleCount, setVisibleCount] = useState(PAGES_PER_BATCH)

  const visiblePages = pages.slice(0, visibleCount)
  const hasMorePreview = visibleCount < pages.length
  const actualTotal = totalPages && totalPages > pages.length ? totalPages : pages.length
  const remainingPreview = pages.length - visibleCount
  const remainingTotal = actualTotal - visibleCount

  const goToPage = useCallback((index: number) => {
    if (index >= 0 && index < visiblePages.length) {
      setCurrentIndex(index)
    }
  }, [visiblePages.length])

  const handleShowMore = useCallback(() => {
    const nextCount = Math.min(visibleCount + PAGES_PER_BATCH, pages.length)
    setVisibleCount(nextCount)
  }, [visibleCount, pages.length])

  const toggleRotate = useCallback(() => {
    setIsRotated(prev => !prev)
  }, [])

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowLeft':
          goToPage(currentIndex - 1)
          break
        case 'ArrowRight':
          goToPage(currentIndex + 1)
          break
        case 'Escape':
          onClose()
          break
        case 'r':
        case 'R':
          toggleRotate()
          break
      }
    }

    document.addEventListener('keydown', handleKeyDown)
    return () => document.removeEventListener('keydown', handleKeyDown)
  }, [currentIndex, goToPage, onClose, toggleRotate])

  useEffect(() => {
    setCurrentIndex(0)
    setIsRotated(false)
    setVisibleCount(PAGES_PER_BATCH)
  }, [pages])

  if (pages.length === 0) {
    return null
  }

  return (
    <section className={`viewer-section${isRotated ? ' rotated' : ''}`}>
      <div className="viewer-header">
        <div className="section-header">
          <h2>Preview</h2>
          <span className="badge">
            {currentIndex + 1} / {visiblePages.length}
            {actualTotal > visiblePages.length ? ` (${actualTotal} total)` : ''}
          </span>
        </div>
        <div className="viewer-controls">
          <button
            className="viewer-btn"
            onClick={toggleRotate}
            aria-label="Rotate view"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/>
              <path d="M21 3v5h-5"/>
            </svg>
          </button>
          <button
            className="viewer-btn"
            onClick={() => {
              const a = document.createElement('a');
              a.href = visiblePages[currentIndex];
              a.download = `page_${currentIndex + 1}.png`;
              a.click();
            }}
            aria-label="Save as PNG"
            title="Save as PNG"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
          </button>
          <div className="viewer-separator" />
          <button
            className="viewer-btn"
            onClick={() => goToPage(currentIndex - 1)}
            disabled={currentIndex === 0}
            aria-label="Previous page"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M15 18l-6-6 6-6"/>
            </svg>
          </button>
          <button
            className="viewer-btn"
            onClick={() => goToPage(currentIndex + 1)}
            disabled={currentIndex === visiblePages.length - 1}
            aria-label="Next page"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M9 18l6-6-6-6"/>
            </svg>
          </button>
          <button
            className="viewer-btn viewer-btn-close"
            onClick={onClose}
            aria-label="Close viewer"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 6L6 18M6 6l12 12"/>
            </svg>
          </button>
        </div>
      </div>
      <div className="viewer-container">
        <div className="viewer-track">
          {visiblePages.map((src, i) => (
            <div 
              key={i} 
              className={`viewer-page${i === currentIndex ? ' active' : ''}`}
            >
              <img src={src} alt={`Page ${i + 1}`} />
            </div>
          ))}
        </div>
      </div>
      <div className="viewer-thumbnails">
        <div className="thumbnail-track">
          {visiblePages.map((src, i) => (
            <button
              key={i}
              className={`thumbnail${i === currentIndex ? ' active' : ''}`}
              onClick={() => goToPage(i)}
            >
              <img src={src} alt={`Page ${i + 1}`} />
            </button>
          ))}
          {(hasMorePreview || remainingTotal > visibleCount) && (
            <button
              className="thumbnail thumbnail-more"
              onClick={hasMorePreview ? handleShowMore : undefined}
              disabled={!hasMorePreview}
              title={hasMorePreview ? `Load ${Math.min(PAGES_PER_BATCH, remainingPreview)} more previews` : `${remainingTotal} pages without preview`}
            >
              <span>+{hasMorePreview ? remainingPreview : remainingTotal - visibleCount}</span>
              <span>{hasMorePreview ? 'show' : 'more'}</span>
            </button>
          )}
        </div>
      </div>
    </section>
  )
}
